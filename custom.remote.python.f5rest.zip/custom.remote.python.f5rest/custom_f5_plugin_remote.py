import json
import logging
import requests
import re
import socket
import time
import _thread
from f5.bigip import ManagementRoot
from f5.utils.responses.handlers import Stats
from requests.auth import HTTPBasicAuth
from requests.adapters import HTTPAdapter
from multiprocessing.pool import ThreadPool
import urllib3

import ruxit.api.selectors
from ruxit.api.base_plugin import RemoteBasePlugin
from ruxit.api.data import PluginMeasurement, PluginProperty, MEAttribute
from ruxit.api.exceptions import AuthException
from ruxit.api.events import Event, EventMetadata

logger = logging.getLogger(__name__)

class Customf5PluginRemote(RemoteBasePlugin):
    # Used for threading
    start = 0
    aLock = _thread.allocate_lock()
    
    # Used for limiting events and ports
    MAX_EVENTS = 99
    events = 0
    
    # For adding endpoints
    listeningPorts = set()
    listeningIPs = set()

    # Used for not spamming events
    previousEvents = []
    raisedEvents = []
    
    # Used to always have debug logging enabled the first run
    firstRun = True

    def query(self, **kwargs):
        self.listeningPorts = set()
        self.listeningIPs = set()
        self.events = 0
        self.raisedEvents = []
        self.start = time.time()
        config = kwargs["config"]
        hostName = config["host_name"].strip().replace("[", "").replace("]", "")
        groupName = config["group"]
        ips = config["ips"]
        if ips.strip() != "":
            for ip in ips.split(","):
                self.listeningIPs.add(ip.strip())
        useToken = config["useToken"]
        
        #create verify request parameter
        verifyCertificate = config["certificate"]
        certificatePath = config["certificatePath"].strip()
        verify = verifyCertificate
        if verify and certificatePath != "":
            verify = certificatePath
        
        debugLogging = config["debug"]
        if debugLogging or self.firstRun:
            debugLogging = True
            logger.setLevel(logging.DEBUG)
            self.firstRun = False
        else:
            logger.setLevel(logging.WARNING)
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
            
        regexVirtualServers = []
        pollVirtualServers = True
        if config["virtualServers"] != "":
            if config["virtualServers"].replace(",", "").replace("'", "").strip().lower() == "none":
                pollVirtualServers = False
                logger.info("Not polling virtual servers")
            else:
                for virtualServer in config["virtualServers"].split(','):
                    regexVirtualServers.append(re.compile(virtualServer.strip() + "$"))
                    logger.info("Adding virtual server filter: " + virtualServer)
            
        regexPools = []
        pollPools = True
        if config["pools"] != "":
            if config["pools"].replace(",", "").replace("'", "").strip().lower() == "none":
                pollPools = False
                logger.info("Not polling pools")
            else:
                for pool in config["pools"].split(','):
                    regexPools.append(re.compile(pool.strip() + "$"))
                    logger.info("Adding pool filter: " + pool)
            
        regexNodes = []
        pollNodes = True
        if config["nodes"] != "":
            if config["nodes"].replace(",", "").replace("'", "").strip().lower() == "none":
                pollNodes = False
                logger.info("Not polling nodes")
            else:
                for node in config["nodes"].split(','):
                    regexNodes.append(re.compile(node.strip() + "$"))
                    logger.info("Adding node filter: " + node)
            
        regexRules = []
        pollRules = True
        if config["rules"] != "":
            if config["rules"].replace(",", "").replace("'", "").strip().lower() == "none":
                pollRules = False
                logger.info("Not polling rules")
            else:
                for rule in config["rules"].split(','):
                    regexRules.append(re.compile(rule.strip() + "$"))
                    logger.info("Adding rule filter: " + rule)
            
        regexProfiles = []
        pollProfiles = True
        if config["profiles"] != "":
            if config["profiles"].replace(",", "").replace("'", "").strip().lower() == "none":
                pollProfiles = False
                logger.info("Not polling profiles")
            else:
                for profile in config["profiles"].split(','):
                    regexProfiles.append(re.compile(profile.strip() + "$"))
                    logger.info("Adding profile filter: " + profile)
            
        regexInterfaces = []
        pollInterfaces = True
        if config["interfaces"] != "":
            if config["interfaces"].replace(",", "").replace("'", "").strip().lower() == "none":
                pollInterfaces = False
                logger.info("Not polling interfaces")
            else:
                for interface in config["interfaces"].split(','):
                    regexInterfaces.append(re.compile(interface.strip() + "$"))
                    logger.info("Adding interface filter: " + interface)
            
        partitions = []
        if config["partitions"] != "":
            for partition in config["partitions"].split(','):
                partitions.append(partition.strip())
                logger.info("Adding partition filter: " + partition)
        
        # Default port
        port = 443
        
        # If entered as 127.0.0.1:1234, extract the ip and the port
        splitHost = hostName.split(":")
        if len(splitHost) > 1:
            hostName = splitHost[0]
            port = splitHost[1]
            
        # Connect to the f5 device
        g1 = self.topology_builder.create_group("f5 - " + groupName, "f5 - " + groupName)
        e1 = g1.create_element("f5 - " + hostName, "f5 - " + hostName)
        e1.report_property("Plugin version", kwargs["json_config"]["version"])
        mgmt = False
        try:
            mgmt = ManagementRoot(hostName, config["auth_user"], config["auth_password"], port=port, token=useToken, verify=verify, timeout=50, debug=debugLogging)
            e1.absolute(key = "connectivity", value = 100)
        except requests.exceptions.RequestException as e:
            logger.exception("Failed polling: " + hostName)
            e1.absolute(key = "connectivity", value = 0)
            if "401" in str(e):
                raise AuthException("Authentication for " + hostName + " (" + str(port) + ") failed for user '" + config["auth_user"] + "'")
            else:
                self.report_custom_info_event(e1, "Connection to " + hostName + " failed", "Connectivity issue")
    
        if mgmt != False:
            e1.report_property("Version", mgmt.tmos_version)
            
            # All the endpoints currently polled
            # printName = name used in events
            # endpoint = method called to get the data
            # nameAttr = name of the endpoint used for splitting, leave out if there is no splitting
            # measureStatus = Create a measure with the status of the endpoint
            # splitName = Splitting dimension
            # limitSplitting = only include splitting if it matches a regex in the passed array
            # metrics = The metrics fetched from the statistics of the endpoint
            # hasStat = Not all endpoints have a stat but gives the results right away (will be improved in a future version of the SDK, https://github.com/F5Networks/f5-common-python/issues/1440)
            # hasCollection = Whether or not the endpoint has a collection of entries or if it is a single entry
            endpoints = []
            virtuals = {"printName": "Virtual server", "endpoint": "ltm/virtual", "nameAttr": "tmName.description", "measureStatus": True, "splitName": "VirtualServer", "limitSplitting": regexVirtualServers, "metrics": [], "hasStat": True, "hasCollection": True, "partitionFilter": True}
            if pollVirtualServers:
                endpoints.append(virtuals)
            pools = {"printName": "Pool", "endpoint": "ltm/pool", "nameAttr": "tmName.description", "measureStatus": True, "splitName": "Pool", "limitSplitting": regexPools, "metrics": [], "hasStat": True, "hasCollection": True, "partitionFilter": True}
            if pollPools:
                endpoints.append(pools)
            rules = {"printName": "Rule", "endpoint": "ltm/rule", "nameAttr": "tmName.description", "nameAttrSuffix": "eventType.description", "measureStatus": False, "splitName": "Rule", "limitSplitting": regexRules, "metrics": [], "hasStat": True, "hasCollection": True, "partitionFilter": True}
            if pollRules:
                endpoints.append(rules)
            nodes = {"printName": "Node", "endpoint": "ltm/node", "nameAttr": "tmName.description", "measureStatus": True, "splitName": "Node", "limitSplitting": regexNodes, "metrics": [], "hasStat": True, "hasCollection": True, "partitionFilter": True}
            if pollNodes:
                endpoints.append(nodes)
            interfaces = {"printName": "Interface", "endpoint": "net/interface", "nameAttr": "tmName.description", "measureStatus": False, "splitName": "Interface", "limitSplitting": regexInterfaces, "metrics": [], "hasStat": True, "hasCollection": True, "partitionFilter": False}
            if pollInterfaces:
                endpoints.append(interfaces)
            client_ssl = {"printName": "Client SSL", "endpoint": "ltm/profile/client-ssl", "nameAttr": "tmName.description", "measureStatus": False, "splitName": "Profile", "limitSplitting": regexProfiles, "metrics": [], "hasStat": True, "hasCollection": True, "partitionFilter": True}
            server_ssl = {"printName": "Server SSL", "endpoint": "ltm/profile/server-ssl", "nameAttr": "tmName.description", "measureStatus": False, "splitName": "Profile", "limitSplitting": regexProfiles, "metrics": [], "hasStat": True, "hasCollection": True, "partitionFilter": True}
            http = {"printName": "HTTP", "endpoint": "ltm/profile/http", "nameAttr": "tmName.description", "measureStatus": False, "splitName": "Profile", "limitSplitting": regexProfiles, "metrics": [], "hasStat": True, "hasCollection": True, "partitionFilter": True}
            if pollProfiles:
                endpoints.append(client_ssl)
                endpoints.append(server_ssl)
                endpoints.append(http)
            disk = {"printName": "Disk", "endpoint": "sys.disk.logical_disks", "nameAttr": "name", "measureStatus": False, "splitName": "Disk", "metrics": [], "hasStat": False, "hasCollection": True, "partitionFilter": False}
            endpoints.append(disk)
            host_info = {"printName": "CPU", "endpoint": "sys.host_info.load().entries.items()", "measureStatus": False, "splitName": "CPU", "metrics": [], "hasStat": False, "hasCollection": False, "partitionFilter": False}
            endpoints.append(host_info)
            snat = {"printName": "SNAT", "endpoint": "ltm.snat_translations", "measureStatus": False, "splitName": "Node", "metrics": [], "hasStat": False, "hasCollection": True, "partitionFilter": False}
            endpoints.append(snat)
            
            # All the metrics currently polled
            # name = Name of the metric as defined in the plugin.json
            # path = Position in the returned json where the metric value is written
            # metric = Absolute or relative
            # expectedValue = If it is a string value instead of a number
            # splitValue = The value of the splitting
            # splitName = The name of the dimension
            # multiplier = Multiply the result with this value
            virtuals["metrics"].append({"name": "VirtualServer.totRequests", "path": "totRequests.value", "metric": "relative"})
            virtuals["metrics"].append({"name": "VirtualServer.clientside_totConns", "path": "clientside_totConns.value", "metric": "relative"})
            virtuals["metrics"].append({"name": "VirtualServer.ephemeral_totConns", "path": "ephemeral_totConns.value", "metric": "relative"})
            virtuals["metrics"].append({"name": "VirtualServer.clientside_bitsIn", "path": "clientside_bitsIn.value", "metric": "relative", "multiplier": 1/8})
            virtuals["metrics"].append({"name": "VirtualServer.ephemeral_bitsIn", "path": "ephemeral_bitsIn.value", "metric": "relative", "multiplier": 1/8})
            virtuals["metrics"].append({"name": "VirtualServer.clientside_bitsOut", "path": "clientside_bitsOut.value", "metric": "relative", "multiplier": 1/8})
            virtuals["metrics"].append({"name": "VirtualServer.ephemeral_bitsOut", "path": "ephemeral_bitsOut.value", "metric": "relative", "multiplier": 1/8})
            virtuals["metrics"].append({"name": "VirtualServer.clientside_pktsIn", "path": "clientside_pktsIn.value", "metric": "relative"})
            virtuals["metrics"].append({"name": "VirtualServer.ephemeral_pktsIn", "path": "ephemeral_pktsIn.value", "metric": "relative"})
            virtuals["metrics"].append({"name": "VirtualServer.clientside_pktsOut", "path": "clientside_pktsOut.value", "metric": "relative"})
            virtuals["metrics"].append({"name": "VirtualServer.ephemeral_pktsOut", "path": "ephemeral_pktsOut.value", "metric": "relative"})
            virtuals["metrics"].append({"name": "VirtualServer.clientside_slowKilled", "path": "clientside_slowKilled.value", "metric": "relative"})
            virtuals["metrics"].append({"name": "VirtualServer.ephemeral_slowKilled", "path": "ephemeral_slowKilled.value", "metric": "relative"})
            virtuals["metrics"].append({"name": "VirtualServer.clientside_evictedConns", "path": "clientside_evictedConns.value", "metric": "relative"})
            virtuals["metrics"].append({"name": "VirtualServer.ephemeral_evictedConns", "path": "ephemeral_evictedConns.value", "metric": "relative"})
            virtuals["metrics"].append({"name": "VirtualServer.oneMinAvgUsageRatio", "path": "oneMinAvgUsageRatio.value", "metric": "absolute"})
            virtuals["metrics"].append({"name": "VirtualServer.syncookie_accepts", "path": "syncookie_accepts.value", "metric": "relative"})
            virtuals["metrics"].append({"name": "VirtualServer.syncookie_rejects", "path": "syncookie_rejects.value", "metric": "relative"})
            pools["metrics"].append({"name": "Pool.totRequests", "path": "totRequests.value", "metric": "relative"})
            pools["metrics"].append({"name": "Pool.serverside_totConns", "path": "serverside_totConns.value", "metric": "relative"})
            pools["metrics"].append({"name": "Pool.serverside_bitsIn", "path": "serverside_bitsIn.value", "metric": "relative", "multiplier": 1/8})
            pools["metrics"].append({"name": "Pool.serverside_bitsOut", "path": "serverside_bitsOut.value", "metric": "relative", "multiplier": 1/8})
            pools["metrics"].append({"name": "Pool.serverside_pktsIn", "path": "serverside_pktsIn.value", "metric": "relative"})
            pools["metrics"].append({"name": "Pool.serverside_pktsOut", "path": "serverside_pktsOut.value", "metric": "relative"})
            pools["metrics"].append({"name": "Pool.activeMemberCnt", "path": "activeMemberCnt.value", "metric": "absolute"})
            pools["metrics"].append({"name": "Pool.curSessions", "path": "curSessions.value", "metric": "absolute"})
            rules["metrics"].append({"name": "Rule.totalExecutions", "path": "totalExecutions.value", "metric": "relative"})
            rules["metrics"].append({"name": "Rule.aborts", "path": "aborts.value", "metric": "relative"})
            rules["metrics"].append({"name": "Rule.failures", "path": "failures.value", "metric": "relative"})
            nodes["metrics"].append({"name": "Node.totRequests", "path": "totRequests.value", "metric": "relative"})
            nodes["metrics"].append({"name": "Node.serverside_totConns", "path": "serverside_totConns.value", "metric": "relative"})
            nodes["metrics"].append({"name": "Node.serverside_bitsIn", "path": "serverside_bitsIn.value", "metric": "relative", "multiplier": 1/8})
            nodes["metrics"].append({"name": "Node.serverside_bitsOut", "path": "serverside_bitsOut.value", "metric": "relative", "multiplier": 1/8})
            nodes["metrics"].append({"name": "Node.serverside_pktsIn", "path": "serverside_pktsIn.value", "metric": "relative"})
            nodes["metrics"].append({"name": "Node.serverside_pktsOut", "path": "serverside_pktsOut.value", "metric": "relative"})
            interfaces["metrics"].append({"name": "Interface.counters_bitsIn", "path": "counters_bitsIn.value", "metric": "relative", "multiplier": 1/8})
            interfaces["metrics"].append({"name": "Interface.counters_bitsOut", "path": "counters_bitsOut.value", "metric": "relative", "multiplier": 1/8})
            interfaces["metrics"].append({"name": "Interface.counters_pktsIn", "path": "counters_pktsIn.value", "metric": "relative"})
            interfaces["metrics"].append({"name": "Interface.counters_pktsOut", "path": "counters_pktsOut.value", "metric": "relative"})
            interfaces["metrics"].append({"name": "Interface.counters_dropsAll", "path": "counters_dropsAll.value", "metric": "relative"})
            interfaces["metrics"].append({"name": "Interface.counters_errorsAll", "path": "counters_errorsAll.value", "metric": "relative"})
            interfaces["metrics"].append({"name": "Interface.status", "path": "status.description", "metric": "relative", "expectedValue": "up"})
            server_ssl["metrics"].append({"name": "ServerSSL.common_totCompatConns", "path": "common_totCompatConns.value", "metric": "relative"})
            server_ssl["metrics"].append({"name": "ServerSSL.common_totNativeConns", "path": "common_totNativeConns.value", "metric": "relative"})
            server_ssl["metrics"].append({"name": "ServerSSL.common_fatalAlerts", "path": "common_fatalAlerts.value", "metric": "relative"})
            server_ssl["metrics"].append({"name": "ServerSSL.common_secureHandshakes", "path": "common_secureHandshakes.value", "metric": "relative"})
            server_ssl["metrics"].append({"name": "ServerSSL.common_handshakeFailures", "path": "common_handshakeFailures.value", "metric": "relative"})
            server_ssl["metrics"].append({"name": "ServerSSL.common_insecureHandshakeAccepts", "path": "common_insecureHandshakeAccepts.value", "metric": "relative"})
            server_ssl["metrics"].append({"name": "ServerSSL.common_insecureHandshakeRejects", "path": "common_insecureHandshakeRejects.value", "metric": "relative"})
            server_ssl["metrics"].append({"name": "ServerSSL.common_insecureRenegotiationRejects", "path": "common_insecureRenegotiationRejects.value", "metric": "relative"})
            server_ssl["metrics"].append({"name": "ServerSSL.common_protocolUses", "path": "common_protocolUses_dtlsv1.value", "metric": "relative", "splitName": "Protocol", "splitValue": "DTLSv1"})
            server_ssl["metrics"].append({"name": "ServerSSL.common_protocolUses", "path": "common_protocolUses_sslv2.value", "metric": "relative", "splitName": "Protocol", "splitValue": "SSLv2"})
            server_ssl["metrics"].append({"name": "ServerSSL.common_protocolUses", "path": "common_protocolUses_sslv3.value", "metric": "relative", "splitName": "Protocol", "splitValue": "SSLv3"})
            server_ssl["metrics"].append({"name": "ServerSSL.common_protocolUses", "path": "common_protocolUses_tlsv1.value", "metric": "relative", "splitName": "Protocol", "splitValue": "TLSv1"})
            server_ssl["metrics"].append({"name": "ServerSSL.common_protocolUses", "path": "common_protocolUses_tlsv1&1.value", "metric": "relative", "splitName": "Protocol", "splitValue": "TLSv1.1"})
            server_ssl["metrics"].append({"name": "ServerSSL.common_protocolUses", "path": "common_protocolUses_tlsv1&2.value", "metric": "relative", "splitName": "Protocol", "splitValue": "TLSv1.2"})
            client_ssl["metrics"].append({"name": "ClientSSL.common_totCompatConns", "path": "common_totCompatConns.value", "metric": "relative"})
            client_ssl["metrics"].append({"name": "ClientSSL.common_totNativeConns", "path": "common_totNativeConns.value", "metric": "relative"})
            client_ssl["metrics"].append({"name": "ClientSSL.common_fatalAlerts", "path": "common_fatalAlerts.value", "metric": "relative"})
            client_ssl["metrics"].append({"name": "ClientSSL.common_secureHandshakes", "path": "common_secureHandshakes.value", "metric": "relative"})
            client_ssl["metrics"].append({"name": "ClientSSL.common_handshakeFailures", "path": "common_handshakeFailures.value", "metric": "relative"})
            client_ssl["metrics"].append({"name": "ClientSSL.common_insecureHandshakeAccepts", "path": "common_insecureHandshakeAccepts.value", "metric": "relative"})
            client_ssl["metrics"].append({"name": "ClientSSL.common_insecureHandshakeRejects", "path": "common_insecureHandshakeRejects.value", "metric": "relative"})
            client_ssl["metrics"].append({"name": "ClientSSL.common_insecureRenegotiationRejects", "path": "common_insecureRenegotiationRejects.value", "metric": "relative"})
            client_ssl["metrics"].append({"name": "ClientSSL.common_protocolUses", "path": "common_protocolUses_dtlsv1.value", "metric": "relative", "splitName": "Protocol", "splitValue": "DTLSv1"})
            client_ssl["metrics"].append({"name": "ClientSSL.common_protocolUses", "path": "common_protocolUses_sslv2.value", "metric": "relative", "splitName": "Protocol", "splitValue": "SSLv2"})
            client_ssl["metrics"].append({"name": "ClientSSL.common_protocolUses", "path": "common_protocolUses_sslv3.value", "metric": "relative", "splitName": "Protocol", "splitValue": "SSLv3"})
            client_ssl["metrics"].append({"name": "ClientSSL.common_protocolUses", "path": "common_protocolUses_tlsv1.value", "metric": "relative", "splitName": "Protocol", "splitValue": "TLSv1"})
            client_ssl["metrics"].append({"name": "ClientSSL.common_protocolUses", "path": "common_protocolUses_tlsv1&1.value", "metric": "relative", "splitName": "Protocol", "splitValue": "TLSv1.1"})
            client_ssl["metrics"].append({"name": "ClientSSL.common_protocolUses", "path": "common_protocolUses_tlsv1&2.value", "metric": "relative", "splitName": "Protocol", "splitValue": "TLSv1.2"})
            http["metrics"].append({"name": "HTTPStats.getReqs", "path": "getReqs.value", "metric": "relative"})
            http["metrics"].append({"name": "HTTPStats.postReqs", "path": "postReqs.value", "metric": "relative"})
            http["metrics"].append({"name": "HTTPStats.resp_2xxCnt", "path": "resp&2xxCnt.value", "metric": "relative"})
            http["metrics"].append({"name": "HTTPStats.resp_3xxCnt", "path": "resp&3xxCnt.value", "metric": "relative"})
            http["metrics"].append({"name": "HTTPStats.resp_4xxCnt", "path": "resp&4xxCnt.value", "metric": "relative"})
            http["metrics"].append({"name": "HTTPStats.resp_5xxCnt", "path": "resp&5xxCnt.value", "metric": "relative"})
            disk["metrics"].append({"name": "Disk.vgFree", "path": "vgFree", "metric": "absolute"})
            disk["metrics"].append({"name": "Disk.vgInUse", "path": "vgInUse", "metric": "absolute"})
            disk["metrics"].append({"name": "Disk.vgReserved", "path": "vgReserved", "metric": "absolute"})
            host_info["metrics"].append({"name": "Host.Memory.Total", "path": "1.'nestedStats'.'entries'.'memoryTotal'.'value'", "metric": "absolute", "splitName": None})
            host_info["metrics"].append({"name": "Host.Memory.Used", "path": "1.'nestedStats'.'entries'.'memoryUsed'.'value'", "metric": "absolute", "splitName": None})
            host_info["metrics"].append({"name": "Host.CPU.oneMinAvgIdle", "path": "'oneMinAvgIdle'.'value'", "metric": "absolute"})
            host_info["metrics"].append({"name": "Host.CPU.oneMinAvgIowait", "path": "'oneMinAvgIowait'.'value'", "metric": "absolute"})
            host_info["metrics"].append({"name": "Host.CPU.oneMinAvgIrq", "path": "'oneMinAvgIrq'.'value'", "metric": "absolute"})
            host_info["metrics"].append({"name": "Host.CPU.oneMinAvgSoftirq", "path": "'oneMinAvgSoftirq'.'value'", "metric": "absolute"})
            host_info["metrics"].append({"name": "Host.CPU.oneMinAvgStolen", "path": "'oneMinAvgStolen'.'value'", "metric": "absolute"})
            host_info["metrics"].append({"name": "Host.CPU.oneMinAvgSystem", "path": "'oneMinAvgSystem'.'value'", "metric": "absolute"})
            host_info["metrics"].append({"name": "Host.CPU.oneMinAvgUser", "path": "'oneMinAvgUser'.'value'", "metric": "absolute"})

            # Due to limitations in the requests session used by the f5 SDK there cannot be more than 10 simultaneous requests
            pool = ThreadPool(processes = 10)
            
            for endpoint in endpoints:
                if endpoint["partitionFilter"] and len(partitions) > 0:
                    for partition in partitions:
                        pool.apply_async(self.callEndPoint, (endpoint, e1, mgmt, partition))
                else:
                    pool.apply_async(self.callEndPoint, (endpoint, e1, mgmt, None))
            pool.close()
            pool.join()
            
            # Max polling time is 50 seconds
            process_alive = 0
            while time.time() - self.start < 50:
                process_alive = 0
                for process in pool._pool:
                    if process.is_alive():
                        process_alive += 1
                if process_alive == 0:
                    logger.info('All processes finished, exiting checking loop')
                    break
                time.sleep(1)
            
            # If we get to this point, a process was flagged alive and it's been more than 50 seconds, then terminate it
            # Otherwise, if process_alive was not set above, then no process should be alive at this point and no need to terminate
            if process_alive > 0:
                pool.terminate()
                pool.join()
                logger.info(str(process_alive) + ' processes are alive. Terminating before finishing polling cycle')
                
            hostNameIsIP = False
            try:
                socket.inet_aton(hostName)
                hostNameIsIP = True
            except socket.error as e:
                hostNameIsIP = False

            if hostNameIsIP:
                self.listeningIPs.add(hostName)
            
            endpointsAssigned = 0
            for ip in self.listeningIPs:
                if ip != "0.0.0.0" and ip != "127.0.0.1":
                    # Check for valid IP
                    ipIsValid = False
                    try:
                        socket.inet_aton(ip)
                        ipIsValid = True
                    except socket.error as e:
                        ipIsValid = False
                    if ipIsValid:
                        try:
                            # Version 163+ allows for an endpoint without port
                            if endpointsAssigned < 100:
                                e1.add_endpoint(ip)
                                logger.info("Adding endpoint " + ip)
                                endpointsAssigned += 1
                            else:
                                logger.info("Too many endpoints, skipping " + ip)
                        except TypeError as e:
                            # Fallback for older versions
                            for port in self.listeningPorts:
                                if not isinstance(port, int) and port.isdigit():
                                    port = int(port)
                                if port > 0 and port < 65536:
                                    if endpointsAssigned < 100:
                                        e1.add_endpoint(ip, int(port))
                                        logger.info("Adding endpoint " + ip + ":" + str(port))
                                        endpointsAssigned += 1
                                    else:
                                        logger.info("Too many endpoints, skipping " + ip + ":" + str(port))
                
            # Register all metrics which contain a result
            for endpoint in endpoints:
                for metric in endpoint["metrics"]:
                    if "splits" in metric:
                        for split in metric["splits"]:
                            if metric["metric"] == "absolute":
                                #logger.info("Adding absolute metric " + metric["name"] + ", value=" + str(split["result"]) + ", dimensions=" + str(split["dimensions"]))
                                e1.absolute(key = metric["name"], value = split["result"], dimensions = split["dimensions"])
                            else:
                                #logger.info("Adding relative metric " + metric["name"] + ", value=" + str(split["result"]) + ", dimensions=" + str(split["dimensions"]))
                                e1.relative(key = metric["name"], value = split["result"], dimensions = split["dimensions"])
                    elif "result" in metric:
                        if metric["metric"] == "absolute":
                            #logger.info("Adding absolute metric " + metric["name"] + ", value=" + str(metric["result"]))
                            e1.absolute(key = metric["name"], value = metric["result"])
                        else:
                            #logger.info("Adding relative metric " + metric["name"] + ", value=" + str(metric["result"]))
                            e1.relative(key = metric["name"], value = metric["result"])
                            
            if debugLogging:
                for call in mgmt.debug_output:
                    logger.info("Performed call: " + call)
        self.previousEvents = self.raisedEvents
                            
    def callEndPoint(self, endpoint, e1, mgmt, partition):
        stat = ""
        try:
            partitionFilter = ""
            if partition != None:
                partitionFilter += "$filter=partition+eq+" + partition + "&"
            selectQuery = []
            for metric in endpoint["metrics"]:
                selectQuery.append(metric["path"].split(".")[0].replace("_", ".").replace("&", "_"))
            if endpoint["measureStatus"]:
                selectQuery.append("status.enabledState")
                selectQuery.append("status.availabilityState")
                selectQuery.append("status.statusReason")
            if "splitName" in endpoint and endpoint["splitName"] == "VirtualServer":
                selectQuery.append("destination")
            if "nameAttr" in endpoint and "tmName" in endpoint["nameAttr"]:
                selectQuery.append("tmName")
            if "nameAttrSuffix" in endpoint and "eventType" in endpoint["nameAttrSuffix"]:
                selectQuery.append("eventType")
            requestStartTime = time.time()
            if endpoint["hasCollection"]:
                if endpoint["hasStat"]:
                    endpointCollection = mgmt.icrs.get(mgmt._meta_data["uri"] + "tm/" + endpoint["endpoint"] + '/stats?' + partitionFilter + '$select=' + ",".join(selectQuery), timeout=48 - (time.time() - self.start)).json()
                    if "entries" in endpointCollection:
                        endpointCollection = endpointCollection["entries"]
                    else:
                        endpointCollection = None
                else:
                    endpointData = self.getChild(mgmt.tm, endpoint["endpoint"])
                    endpointCollection = endpointData.get_collection(requests_params={'params': partitionFilter})   
            else:
                endpointCollection = self.getChild(mgmt.tm, endpoint["endpoint"])
            # Loop through the splittings
            if endpointCollection is not None:
                for collection in endpointCollection:
                    printedStat = False
                    if isinstance(collection, str):
                        collection = endpointCollection[collection]["nestedStats"]["entries"]
                    if "nameAttr" in endpoint:
                        name = self.getChild(collection, endpoint["nameAttr"])
                        if name.count("/") == 2:
                            name = name.split("/")[2]
                    else:
                        name = ""
                    if "nameAttrSuffix" in endpoint:
                        name += "/" + self.getChild(collection, endpoint["nameAttrSuffix"])
                    if "limitSplitting" not in endpoint or self.limitByRegEx(endpoint["limitSplitting"], name):
                        stat = collection
                        if stat is not None:
                            for metric in endpoint["metrics"]:
                                if endpoint["printName"] == "CPU" and "splitName" not in metric:
                                    try:
                                        for item in collection[1]["nestedStats"]["entries"]:
                                            if "cpuInfo" in item:
                                                for subItem in collection[1]["nestedStats"]["entries"][item]["nestedStats"]["entries"]:
                                                    value = self.getChild(collection[1]["nestedStats"]["entries"][item]["nestedStats"]["entries"][subItem]["nestedStats"]["entries"], metric["path"])
                                                    dimensions = {}
                                                    dimensions[endpoint["splitName"]] = str(collection[1]["nestedStats"]["entries"][item]["nestedStats"]["entries"][subItem]["nestedStats"]["entries"]["cpuId"]["value"])
                                                    if not "splits" in metric:
                                                        metric["splits"] = []
                                                    if len(metric["splits"]) < 100:
                                                        metric["splits"].append({"result": value, "dimensions": dimensions})
                                    except Exception as e:
                                        logger.exception(e)
                                        logger.warning("No CPU metrics for " + metric["path"])
                                        if printedStat == False:
                                            logger.warning(stat)
                                            printedStat = True
                                else:
                                    # Get the value, check if it is what it's supposed to be, multiply, split and store it in the metric variable
                                    value = self.getChild(stat, metric["path"])
                                    if value != None:
                                        if "expectedValue" in metric:
                                            if metric["expectedValue"] == value:
                                                value = 100
                                            else:
                                                value = 0
                                        multiplier = 1
                                        if "multiplier" in metric:
                                            multiplier = metric["multiplier"]
                                        splitName = None
                                        if "splitName" in metric:
                                            splitName = metric["splitName"]
                                        elif "splitName" in endpoint:
                                            splitName = endpoint["splitName"]
                                        value *= multiplier
                                        if splitName is not None:
                                            dimensions = {}
                                            if not "splits" in metric:
                                                metric["splits"] = []
                                            if "splitName" in endpoint:
                                                dimensions[endpoint["splitName"]] = name
                                            if "splitName" in metric:
                                                dimensions[metric["splitName"]] = metric["splitValue"]
                                            if len(metric["splits"]) < 100:
                                                metric["splits"].append({"result": value, "dimensions": dimensions})
                                        else:
                                            metric["result"] = value
                                    else:
                                        logger.info("No value for " + metric["path"])
                                        if printedStat == False:
                                            logger.info(stat)
                                            printedStat = True
                            # Check if the splitting is reporting that it's available if it is enabled
                            if endpoint["measureStatus"]:
                                availability = 100
                                enabledState = "status.enabledState"
                                availabilityState = "status.availabilityState"
                                statusReason = "status.statusReason"
                                if "status_enabledState" in stat:
                                    enabledState = "status_enabledState"
                                    availabilityState = "status_availabilityState"
                                    statusReason = "status_statusReason"
                                enabled = stat[enabledState]["description"]
                                if enabled == "enabled":
                                    available = stat[availabilityState]["description"].lower()
                                    if available == "unknown":
                                        # Unknown if sub-status isn't checked
                                        availability = -1
                                    elif available != "available":
                                        availability = 0
                                        with self.aLock:
                                            self.report_custom_info_event(e1, endpoint["printName"] + " '" + name + "' is not available, it is '" + available + "'. Reason: " + stat[statusReason]["description"], name + " unavailable")
                                if availability >= 0:
                                    with self.aLock:
                                        e1.absolute(key = endpoint["splitName"] + ".Status", value = availability, dimensions = {endpoint["splitName"]: name})
                            if "splitName" in endpoint:
                                # Add the listen IP/port if it is a virtual server
                                if endpoint["splitName"] == "VirtualServer":
                                    listenPorts = stat["destination"]["description"].split(":")
                                    if len(listenPorts) > 1:
                                        with self.aLock:
                                            self.listeningIPs.add(listenPorts[0].split("%")[0])
                                            if listenPorts[1].isdigit() and int(listenPorts[1]) > 0: # Only add real ports, not "any"
                                                self.listeningPorts.add(listenPorts[1])
                                    else:
                                        with self.aLock:
                                            self.listeningIPs.add(listenPorts[0])
                    # Add the listen IP/port if it is a SNAT translation
                    if endpoint["printName"] == "SNAT":
                        if collection.enabled:
                            if "%" in collection.address:
                                with self.aLock:
                                    self.listeningIPs.add(collection.address.split("%")[0])
                                    self.listeningPorts.add(443)
                                logger.info("Added SNAT ip " + collection.address.split("%")[0] + " from " + collection.address)
                            else:
                                with self.aLock:
                                    self.listeningIPs.add(collection.address)
                                    self.listeningPorts.add(443)
                                logger.info("Added SNAT ip " + collection.address)
            logger.info("Endpoint: " + endpoint["endpoint"] + ", performance: " + str(time.time() - requestStartTime) + "s")
        except KeyError as e:
            logger.info("Key not found for endpoint: " + str(endpoint) + ", stat: " + str(stat))
            logger.exception(e)
        except requests.exceptions.RequestException as e:
            logger.info("Failed polling endpoint: " + str(endpoint))
            logger.exception(e)
        except Exception as e:
            logger.info("Failed polling endpoint: " + str(endpoint))
            logger.exception(e)
        self.callsToGo -= 1
        self.activeThreads -= 1
        
    def limitByRegEx(self, regexes, string):
        passed = False
        if len(regexes) == 0:
            passed = True
            logger.info("Matching string due to 0 size RegEx: " + string)
        else:
            for regex in regexes:
                if regex.match(string):
                    passed = True
                    logger.info("Matching string due to RegEx '" + str(regex) + "': " + string)
                    break
        if not passed:
            logger.info("Limiting by RegEx, name: " + string)
        return passed

    # Helper method which calls methods and gets fields based on a string
    def getChild(self, object, path):
        child = object
        for method in path.split("."):
            if method.isdigit():
                child = child[int(method)]
            elif self.isIterable(child) and method in child:
                child = child[method]
            elif self.isIterable(child) and method.replace("_", ".").replace("&", "_") in child:
                child = child[method.replace("_", ".").replace("&", "_")]
            elif "'" in method:
                child = child[method[1:-1]]
            elif "()" in method:
                child = getattr(child, method[:-2])()
            elif hasattr(child, method):
                child = getattr(child, method)
            elif hasattr(child, method.replace("_", ".").replace("&", "_")):
                child = getattr(child, method.replace("_", ".").replace("&", "_"))
            else:
                return None
        return child
    
    def isIterable(self, object):
        try:
            iterator = iter(object)
        except TypeError:
            return False
        return True
        
    def report_custom_info_event(self, e1, message, title):
        if self.events < self.MAX_EVENTS:
            if title + message not in self.previousEvents:
                self.events += 1
                e1.report_custom_info_event(message, title)
            self.raisedEvents.append(title + message)